# -*- coding: utf-8 -*-
"""
Created on Fri Aug  8 10:44:42 2025
__init__.py fole
@author: Mahjobe Nazari
"""

from .library import Library